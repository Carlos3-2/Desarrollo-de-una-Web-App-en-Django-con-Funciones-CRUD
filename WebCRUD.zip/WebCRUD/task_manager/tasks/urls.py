from .import views
from django.urls import path

from .views import task_list, task_detail, create_task, update_task, delete_task

urlpatterns = [
    path('', task_list, name='task_list'),
    path('task/<int:pk>/', task_detail, name='task_detail'),
    path('task/new/', create_task, name='create_task'),
    path('task/<int:pk>/edit/', update_task, name='update_task'),
    path('task/<int:pk>/delete/', delete_task, name='delete_task'),
]